# 🚀 Art Seek - Quick Start Guide

## 📲 Installation (60 seconds)

### iPhone Users
1. Open this page in **Safari** browser
2. Tap the **Share** button (⬆️ icon at bottom)
3. Scroll and tap **"Add to Home Screen"**
4. Tap **"Add"** in the top right
5. Find Art Seek icon on your home screen
6. Tap to launch! 🎉

### That's it! You're ready to explore.

---

## 🎮 How to Play

### 1. Scan Your First Artifact 📸
- Tap the big **camera button** at the bottom
- Allow camera access when prompted
- Point camera at any museum artifact
- Tap **"Capture Artifact!"**

### 2. Fill in Details 📝
- Name your artifact (e.g., "Ancient Greek Vase")
- Add museum name (e.g., "Musée des Beaux-Arts")
- Add location (e.g., "Dijon, France")
- Tap **"Save Discovery"**

### 3. View Your Collection 🖼️
- Go to **"Gallery"** tab to see all artifacts
- Tap any artifact to see full details
- See museum location and GPS coordinates
- Delete artifacts you don't want

### 4. Track Museums 🗺️
- Go to **"Museums"** tab
- See how many artifacts found at each museum
- Track countries you've explored
- View your global collection stats

### 5. Add Friends 👥
- Go to **"Friends"** tab
- Tap **"Add Friend"**
- Enter their name
- Start building your explorer crew!

### 6. Level Up! ⭐
- Find 3 artifacts = Level 2
- Every 3 artifacts = new level
- Watch your progress bar at the top
- Unlock achievements as you explore

---

## 💡 Pro Tips

### Taking Great Photos
- ✅ Use good lighting
- ✅ Get close to the artifact
- ✅ Hold phone steady
- ✅ Center the artifact in frame

### Museum Etiquette
- 📵 Turn off flash
- 🤫 Stay quiet
- 👀 Check museum photo policies
- 🚫 Don't touch artifacts

### Organizing Your Collection
- 📝 Add detailed descriptions
- 📍 Always add museum location
- 🏷️ Use clear, specific names
- 🗑️ Delete duplicates

### Maximizing Battery
- 🔋 Lower screen brightness
- ✈️ Use airplane mode after install
- 📴 Works fully offline once installed
- ⚡ Close other apps while scanning

---

## 🎯 Goals & Achievements

### Beginner Explorer (Levels 1-5)
- Find your first 15 artifacts
- Visit at least 2 museums
- Add your first friend

### Museum Expert (Levels 6-10)
- Collect 30+ artifacts
- Visit 5+ different museums
- Build a crew of 3+ friends

### Master Collector (Levels 11+)
- Collect 50+ artifacts
- Visit 10+ museums
- Explore 3+ countries

---

## 📱 App Navigation

### Bottom Navigation
- **📸 Camera Button**: Scan new artifacts (center)

### Top Tabs
- **🖼️ Gallery**: View your collection
- **🗺️ Museums**: Track locations visited
- **👥 Friends**: Manage your explorer crew
- **🏆 Trades**: View trade history

### Header
- **⭐ Level Badge**: Shows current level
- **Progress Bar**: Track to next level

---

## 🆘 Common Questions

**Q: Do I need internet to use the app?**
A: No! After installation, browse your collection offline. You only need internet to scan new artifacts (for GPS tagging).

**Q: How many artifacts can I collect?**
A: Unlimited! Storage depends on your device space. Each artifact uses ~300KB.

**Q: Can I edit an artifact after saving?**
A: Not yet - but coming soon! For now, delete and re-scan if needed.

**Q: How do I trade with friends?**
A: Go to Friends tab → Tap friend → Tap "Trade" → Select artifact to share!

**Q: Does this drain my battery?**
A: Minimal drain. Camera uses battery when scanning, but normal browsing is very efficient.

**Q: Can I backup my collection?**
A: Currently stored locally. Backup feature coming soon!

**Q: What if I delete the app?**
A: Your data is lost if you delete from home screen. Don't worry - just don't delete it!

---

## 🎨 Best Practices

### At Museums
1. Read museum rules first
2. Ask permission if unsure about photos
3. Be respectful of other visitors
4. Focus on learning, not just collecting

### Managing Collection
- Scan regularly during visits
- Add details immediately (don't forget!)
- Review gallery weekly
- Share favorites with friends

### Social Features
- Add friends who also visit museums
- Share interesting finds
- Compare collections
- Explore together!

---

## 🌟 Fun Challenges

### Daily Challenge
📸 Scan at least 1 artifact per day

### Weekly Challenge
🏛️ Visit a new museum this week

### Monthly Challenge
🌍 Collect artifacts from 3 different museums

### Ultimate Challenge
🏆 Reach Level 10 and collect 50+ artifacts from 5+ countries!

---

## 📞 Need Help?

### Installation Issues
- Make sure you're using Safari
- Update iOS to latest version
- Check device storage space

### Camera Not Working
- Settings → Safari → Camera → Allow
- Or Settings → Art Seek → Camera

### App Not Loading
- Close and reopen
- Check internet connection
- Reinstall if needed

---

**Happy exploring! Start your museum adventure now! 🎨🏛️✨**

---

**Pro Tip**: Visit the Friends tab to install the app for easy access!
