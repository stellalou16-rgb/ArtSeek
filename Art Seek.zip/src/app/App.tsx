'use client';
import { useState, useEffect } from 'react';
import {
  Camera,
  ImageIcon,
  Users,
  Sparkles,
  Trophy,
  Map,
} from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { Badge } from '@/app/components/ui/badge';
import { CameraScanner } from '@/app/components/CameraScanner';
import { ArtifactGallery, type Artifact } from '@/app/components/ArtifactGallery';
import { TradingInterface, TradeHistory } from '@/app/components/TradingInterface';
import { FriendsList } from '@/app/components/FriendsList';
import { MuseumStats } from '@/app/components/MuseumStats';
import { InstallPrompt } from '@/app/components/InstallPrompt';
import { Toaster, toast } from 'sonner';

const STORAGE_KEY = 'museum_artifacts';

export default function Home() {
  const [showScanner, setShowScanner] = useState(false);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [selectedArtifactForTrade, setSelectedArtifactForTrade] = useState<Artifact | null>(null);
  const [activeTab, setActiveTab] = useState('gallery');
  const [cameraAllowed, setCameraAllowed] = useState<boolean | null>(null);

  // Mobile detection
  const [isMobile, setIsMobile] = useState(true);
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  // Load artifacts
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) setArtifacts(JSON.parse(stored));
  }, []);

  useEffect(() => {
    artifacts.length
      ? localStorage.setItem(STORAGE_KEY, JSON.stringify(artifacts))
      : localStorage.removeItem(STORAGE_KEY);
  }, [artifacts]);

  // Early return AFTER all hooks
  if (!isMobile)
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center p-6 max-w-sm">
          <h2 className="text-2xl font-bold mb-2">📱 Mobile Only</h2>
          <p className="text-gray-600">Art Seek is designed exclusively for mobile devices.</p>
        </div>
      </div>
    );

  const isCameraSupported = !!navigator.mediaDevices?.getUserMedia;

  const requestCameraPermission = async () => {
    if (!isCameraSupported) {
      toast.error('Camera not supported on this device.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      stream.getTracks().forEach(track => track.stop());
      setCameraAllowed(true);
      setShowScanner(true);
    } catch {
      setCameraAllowed(false);
      toast.error('Camera Access Denied', { description: 'Enable camera access in iPhone Settings → Safari → Camera.' });
    }
  };

  const playerLevel = Math.floor(artifacts.length / 3) + 1;
  const artifactsToNextLevel = 3 - (artifacts.length % 3);

  return (
    <div className="min-h-screen flex justify-center bg-gray-200 overflow-x-hidden">
      <div className="w-full max-w-[430px] min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-blue-100 shadow-2xl relative overflow-x-hidden pb-[env(safe-area-inset-bottom)]">
        <Toaster />

        {/* HEADER */}
        <header className="sticky top-0 z-40 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 shadow-xl pt-[env(safe-area-inset-top)]">
          <div className="px-4 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center shadow-lg rotate-12 border-4 border-white">
                  <Sparkles className="w-7 h-7 text-white -rotate-12" />
                </div>
                <div>
                  <h1 className="text-3xl font-black text-white">Art Seek 🎨</h1>
                  <p className="text-sm text-purple-100 font-semibold">Discover & Collect Treasures!</p>
                </div>
              </div>
              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-2 border-white shadow-lg px-3 py-1">
                <Trophy className="w-4 h-4 mr-1" />
                Level {playerLevel}
              </Badge>
            </div>

            <div className="mt-3 bg-white/30 rounded-full h-3 overflow-hidden border border-white/50">
              <div className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all"
                   style={{ width: `${((artifacts.length % 3) / 3) * 100}%` }} />
            </div>

            <p className="text-xs text-white text-center mt-1 font-semibold">
              {artifactsToNextLevel === 3 ? 'Find 3 artifacts to reach Level 2!' : `${artifactsToNextLevel} more to Level ${playerLevel + 1}!`}
            </p>
          </div>
        </header>

        {/* TABS */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="sticky top-[140px] z-30 bg-white/90 backdrop-blur-md shadow-md rounded-b-2xl px-2 pb-2">
            <TabsList className="grid grid-cols-4 w-full bg-transparent">
              {[
                ['gallery', ImageIcon, 'Gallery'],
                ['museums', Map, 'Museums'],
                ['friends', Users, 'Friends'],
                ['trades', Trophy, 'Trades'],
              ].map(([key, Icon, label]) => (
                <TabsTrigger
                  key={key as string}
                  value={key as string}
                  className="flex flex-col items-center gap-1 py-2 text-xs font-bold min-h-[44px] rounded-xl data-[state=active]:bg-purple-100"
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <main className="pt-4 pb-28 px-2">
            <TabsContent value="gallery">
              <ArtifactGallery artifacts={artifacts} onDelete={id => setArtifacts(artifacts.filter(a => a.id !== id))} onSelectForTrade={setSelectedArtifactForTrade} />
            </TabsContent>

            <TabsContent value="museums">
              <MuseumStats artifacts={artifacts} />
            </TabsContent>

            <TabsContent value="friends">
              <FriendsList />
            </TabsContent>

            <TabsContent value="trades">
              <TradeHistory />
            </TabsContent>
          </main>
        </Tabs>

        {/* FAB */}
        <div className="fixed left-1/2 -translate-x-1/2 bottom-[calc(1.5rem+env(safe-area-inset-bottom))] z-50">
          <Button
            onClick={requestCameraPermission}
            className="h-16 w-16 rounded-full bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-500 border-4 border-white shadow-2xl active:scale-90 transition-transform"
          >
            <Camera className="w-7 h-7" />
          </Button>
        </div>

        {showScanner && cameraAllowed && (
          <CameraScanner onCapture={artifact => setArtifacts([artifact, ...artifacts])} onClose={() => setShowScanner(false)} />
        )}

        <TradingInterface selectedArtifact={selectedArtifactForTrade} onClose={() => setSelectedArtifactForTrade(null)} onTrade={() => {}} />
        <InstallPrompt />
      </div>
    </div>
  );
}