import { Trash2, Share2, Info, Sparkles, Star, Trophy, MapPin, Globe } from 'lucide-react';
import { Card, CardContent } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/app/components/ui/dialog';
import { useState } from 'react';

export interface Artifact {
  id: string;
  image: string;
  name: string;
  description: string;
  dateScanned: string;
  museumName: string;
  location: string;
  coordinates?: { lat: number; lng: number };
}

interface ArtifactGalleryProps {
  artifacts: Artifact[];
  onDelete: (id: string) => void;
  onSelectForTrade: (artifact: Artifact) => void;
}

export function ArtifactGallery({ artifacts, onDelete, onSelectForTrade }: ArtifactGalleryProps) {
  const [selectedArtifact, setSelectedArtifact] = useState<Artifact | null>(null);

  if (artifacts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 px-4 text-center">
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center mb-4 shadow-lg">
          <Sparkles className="w-12 h-12 text-white" />
        </div>
        <h3 className="text-2xl mb-2 font-bold text-purple-900">Start Your Adventure! 🎨</h3>
        <p className="text-gray-600 max-w-md mb-4">
          No artifacts yet! Use the camera to scan your first museum treasure and begin your collection!
        </p>
        <div className="flex gap-2">
          <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 border-0">
            <Trophy className="w-3 h-3 mr-1" />
            Explorer Level 1
          </Badge>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
        {artifacts.map((artifact, index) => (
          <Card key={artifact.id} className="overflow-hidden hover:shadow-2xl transition-all hover:scale-105 border-4 border-purple-200 bg-gradient-to-br from-white to-purple-50">
            <div 
              className="aspect-square bg-gradient-to-br from-purple-100 to-pink-100 overflow-hidden cursor-pointer relative group"
              onClick={() => setSelectedArtifact(artifact)}
            >
              <img
                src={artifact.image}
                alt={artifact.name}
                className="w-full h-full object-cover hover:scale-110 transition-transform"
              />
              <div className="absolute top-2 right-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg flex items-center gap-1">
                <Star className="w-3 h-3" />
                #{index + 1}
              </div>
            </div>
            <CardContent className="p-4">
              <h3 className="font-bold mb-1 truncate text-purple-900">✨ {artifact.name}</h3>
              {artifact.description && (
                <p className="text-sm text-gray-600 mb-2 line-clamp-2">{artifact.description}</p>
              )}
              <div className="mb-2">
                <Badge className="text-xs bg-gradient-to-r from-blue-400 to-cyan-500 border-0 text-white">
                  <MapPin className="w-3 h-3 mr-1" />
                  {artifact.location}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <Badge variant="secondary" className="text-xs bg-gradient-to-r from-purple-200 to-pink-200 border-0">
                  📅 {new Date(artifact.dateScanned).toLocaleDateString()}
                </Badge>
                <div className="flex gap-1">
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => onSelectForTrade(artifact)}
                    className="h-8 w-8 hover:bg-purple-100 rounded-full"
                  >
                    <Share2 className="w-4 h-4 text-purple-600" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => onDelete(artifact.id)}
                    className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-full"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!selectedArtifact} onOpenChange={() => setSelectedArtifact(null)}>
        <DialogContent className="max-w-2xl border-4 border-purple-300 bg-gradient-to-br from-purple-50 to-pink-50">
          <DialogHeader>
            <DialogTitle className="text-2xl text-purple-900 flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-yellow-500" />
              {selectedArtifact?.name}
            </DialogTitle>
            <DialogDescription className="text-purple-700">
              🗓️ Discovered on {selectedArtifact && new Date(selectedArtifact.dateScanned).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </DialogDescription>
          </DialogHeader>
          {selectedArtifact && (
            <div className="space-y-4">
              <img
                src={selectedArtifact.image}
                alt={selectedArtifact.name}
                className="w-full rounded-xl border-4 border-white shadow-lg"
              />
              
              {/* Museum Location Card */}
              <div className="bg-gradient-to-r from-blue-100 to-cyan-100 rounded-2xl p-4 border-4 border-blue-300 shadow-md">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <Globe className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-blue-900 mb-1">🏛️ {selectedArtifact.museumName}</h4>
                    <p className="text-blue-700 text-sm flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {selectedArtifact.location}
                    </p>
                    {selectedArtifact.coordinates && (
                      <p className="text-xs text-blue-600 mt-2 bg-blue-50 rounded-lg px-2 py-1 inline-block">
                        🌍 GPS: {selectedArtifact.coordinates.lat.toFixed(4)}°, {selectedArtifact.coordinates.lng.toFixed(4)}°
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {selectedArtifact.description && (
                <div className="bg-white/60 rounded-xl p-4 border-2 border-purple-200">
                  <h4 className="font-bold mb-2 text-purple-900">📖 Description</h4>
                  <p className="text-gray-700">{selectedArtifact.description}</p>
                </div>
              )}
              <div className="flex gap-2">
                <Button
                  onClick={() => {
                    onSelectForTrade(selectedArtifact);
                    setSelectedArtifact(null);
                  }}
                  className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 rounded-xl shadow-lg"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share with Friends! 🎁
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}