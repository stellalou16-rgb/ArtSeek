import { MapPin, Globe, Trophy, Sparkles } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { ScrollArea } from '@/app/components/ui/scroll-area';
import type { Artifact } from './ArtifactGallery';

interface MuseumStatsProps {
  artifacts: Artifact[];
}

interface MuseumVisit {
  name: string;
  location: string;
  count: number;
  lastVisit: string;
}

export function MuseumStats({ artifacts }: MuseumStatsProps) {
  // Group artifacts by museum
  const museumVisits = artifacts.reduce((acc, artifact) => {
    const key = `${artifact.museumName}|${artifact.location}`;
    if (!acc[key]) {
      acc[key] = {
        name: artifact.museumName,
        location: artifact.location,
        count: 0,
        lastVisit: artifact.dateScanned,
      };
    }
    acc[key].count++;
    if (new Date(artifact.dateScanned) > new Date(acc[key].lastVisit)) {
      acc[key].lastVisit = artifact.dateScanned;
    }
    return acc;
  }, {} as Record<string, MuseumVisit>);

  const museums = Object.values(museumVisits).sort((a, b) => b.count - a.count);
  const uniqueCountries = new Set(artifacts.map(a => a.location.split(',').pop()?.trim())).size;
  const totalMuseums = museums.length;

  if (artifacts.length === 0) {
    return (
      <div className="p-4">
        <Card className="border-4 border-blue-200 bg-gradient-to-br from-blue-50 to-cyan-50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-400 to-cyan-500 flex items-center justify-center mb-4">
              <Globe className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-lg font-bold mb-2 text-blue-900">No Museums Yet! 🗺️</h3>
            <p className="text-gray-600 text-center max-w-xs">
              Start exploring museums and collecting artifacts to unlock your travel map!
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card className="border-4 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 mx-auto bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mb-2">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div className="text-3xl font-black text-purple-900">{artifacts.length}</div>
            <div className="text-sm text-purple-700 font-semibold">Artifacts Found</div>
          </CardContent>
        </Card>

        <Card className="border-4 border-blue-200 bg-gradient-to-br from-blue-50 to-cyan-50">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 mx-auto bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mb-2">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <div className="text-3xl font-black text-blue-900">{totalMuseums}</div>
            <div className="text-sm text-blue-700 font-semibold">Museums Visited</div>
          </CardContent>
        </Card>

        <Card className="border-4 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 mx-auto bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center mb-2">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <div className="text-3xl font-black text-green-900">{uniqueCountries}</div>
            <div className="text-sm text-green-700 font-semibold">Countries Explored</div>
          </CardContent>
        </Card>
      </div>

      {/* Museum List */}
      <Card className="border-4 border-purple-300 bg-gradient-to-br from-white to-purple-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-purple-900">
            <MapPin className="w-6 h-6 text-purple-600" />
            Your Museum Journey 🗺️
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {museums.map((museum, index) => (
                <Card
                  key={`${museum.name}-${museum.location}`}
                  className="border-2 border-purple-200 hover:shadow-lg transition-all bg-gradient-to-br from-white to-blue-50"
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-cyan-500 rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                        <span className="text-white font-bold text-sm">#{index + 1}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-purple-900 mb-1 truncate">
                          🏛️ {museum.name}
                        </h3>
                        <p className="text-sm text-blue-700 flex items-center gap-1 mb-2">
                          <MapPin className="w-3 h-3" />
                          {museum.location}
                        </p>
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 border-0 text-white text-xs">
                            <Sparkles className="w-3 h-3 mr-1" />
                            {museum.count} {museum.count === 1 ? 'artifact' : 'artifacts'}
                          </Badge>
                          <Badge variant="secondary" className="text-xs bg-purple-100 border-0">
                            Last: {new Date(museum.lastVisit).toLocaleDateString()}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
