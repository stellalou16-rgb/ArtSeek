import { useRef, useState, useEffect } from 'react';
import { Camera, X, Check, Sparkles, MapPin } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Card } from '@/app/components/ui/card';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';

interface CameraScannerProps {
  onCapture: (artifact: { 
    id: string; 
    image: string; 
    name: string; 
    description: string; 
    dateScanned: string;
    museumName: string;
    location: string;
    coordinates?: { lat: number; lng: number };
  }) => void;
  onClose: () => void;
}

export function CameraScanner({ onCapture, onClose }: CameraScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [artifactName, setArtifactName] = useState('');
  const [artifactDescription, setArtifactDescription] = useState('');
  const [museumName, setMuseumName] = useState('');
  const [location, setLocation] = useState('');
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  useEffect(() => {
    startCamera();
    getLocation();
    return () => {
      stopCamera();
    };
  }, []);

  const getLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCoordinates({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.log('Geolocation error:', error);
          // Silent fail - location is optional
        }
      );
    }
  };

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setCameraError(null);
    } catch (error) {
      console.error('Error accessing camera:', error);
      setCameraError('Unable to access camera. Please check your permissions.');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const imageData = canvas.toDataURL('image/jpeg', 0.9);
        setCapturedImage(imageData);
        stopCamera();
      }
    }
  };

  const retakePhoto = () => {
    setCapturedImage(null);
    setArtifactName('');
    setArtifactDescription('');
    setMuseumName('');
    setLocation('');
    startCamera();
  };

  const saveArtifact = () => {
    if (capturedImage && artifactName && museumName && location) {
      const artifact = {
        id: Date.now().toString(),
        image: capturedImage,
        name: artifactName,
        description: artifactDescription,
        dateScanned: new Date().toISOString(),
        museumName: museumName,
        location: location,
        coordinates: coordinates || undefined,
      };
      onCapture(artifact);
    }
  };

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 z-50 flex flex-col">
      <div className="flex items-center justify-between p-4 bg-black/30 backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-yellow-400" />
          <h2 className="text-white text-xl font-bold">Scan Artifact!</h2>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20 rounded-full">
          <X className="w-6 h-6" />
        </Button>
      </div>

      <div className="flex-1 flex items-center justify-center p-4 overflow-y-auto">
        {cameraError ? (
          <Card className="p-6 max-w-md border-4 border-red-300 bg-gradient-to-br from-red-50 to-pink-50">
            <p className="text-center text-red-600 mb-4">{cameraError}</p>
            <Button onClick={startCamera} className="w-full bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600">
              Retry
            </Button>
          </Card>
        ) : capturedImage ? (
          <Card className="w-full max-w-2xl p-6 space-y-4 border-4 border-purple-300 bg-gradient-to-br from-purple-50 to-pink-50 shadow-2xl my-4">
            <img src={capturedImage} alt="Captured artifact" className="w-full rounded-xl border-4 border-white shadow-lg" />
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-purple-900 font-semibold">✨ Artifact Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Ancient Greek Vase"
                  value={artifactName}
                  onChange={(e) => setArtifactName(e.target.value)}
                  className="border-2 border-purple-300 focus:border-purple-500 rounded-xl"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-purple-900 font-semibold">📝 Description (optional)</Label>
                <Input
                  id="description"
                  placeholder="Add details about the artifact..."
                  value={artifactDescription}
                  onChange={(e) => setArtifactDescription(e.target.value)}
                  className="border-2 border-purple-300 focus:border-purple-500 rounded-xl"
                />
              </div>

              <div className="bg-gradient-to-r from-blue-100 to-cyan-100 rounded-2xl p-4 border-2 border-blue-300">
                <div className="flex items-center gap-2 mb-3">
                  <MapPin className="w-5 h-5 text-blue-600" />
                  <Label className="text-blue-900 font-bold">📍 Museum Location</Label>
                </div>
                
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="museum" className="text-blue-900 font-semibold text-sm">Museum Name *</Label>
                    <Input
                      id="museum"
                      placeholder="e.g., Musée des Beaux-Arts"
                      value={museumName}
                      onChange={(e) => setMuseumName(e.target.value)}
                      className="border-2 border-blue-300 focus:border-blue-500 rounded-xl bg-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location" className="text-blue-900 font-semibold text-sm">City, Country *</Label>
                    <Input
                      id="location"
                      placeholder="e.g., Dijon, France"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="border-2 border-blue-300 focus:border-blue-500 rounded-xl bg-white"
                    />
                  </div>

                  {coordinates && (
                    <div className="text-xs text-blue-700 bg-blue-50 rounded-lg p-2 border border-blue-200">
                      🌍 GPS: {coordinates.lat.toFixed(4)}°, {coordinates.lng.toFixed(4)}°
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={retakePhoto} className="flex-1 border-2 border-purple-300 hover:bg-purple-100 rounded-xl">
                  Retake
                </Button>
                <Button 
                  onClick={saveArtifact} 
                  disabled={!artifactName || !museumName || !location} 
                  className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 rounded-xl shadow-lg"
                >
                  <Check className="w-4 h-4 mr-2" />
                  Save Discovery
                </Button>
              </div>
            </div>
          </Card>
        ) : (
          <div className="relative w-full max-w-2xl">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full rounded-2xl border-4 border-white/30 shadow-2xl"
            />
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-64 h-64 border-4 border-yellow-400 rounded-2xl shadow-lg animate-pulse"></div>
            </div>
          </div>
        )}
      </div>

      {!capturedImage && !cameraError && (
        <div className="p-6 bg-black/30 backdrop-blur-sm">
          <Button 
            onClick={capturePhoto} 
            className="w-full h-16 bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-500 hover:from-yellow-500 hover:via-orange-600 hover:to-pink-600 rounded-2xl shadow-2xl text-lg font-bold" 
            size="lg"
          >
            <Camera className="w-6 h-6 mr-2" />
            Capture Artifact! 📸
          </Button>
        </div>
      )}

      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}