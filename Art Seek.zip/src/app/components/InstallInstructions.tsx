import { Info, Share, Download, CheckCircle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/app/components/ui/dialog';
import { Button } from '@/app/components/ui/button';
import { Card, CardContent } from '@/app/components/ui/card';

export function InstallInstructions() {
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
                      (window.navigator as any).standalone;

  if (isStandalone) {
    return (
      <Card className="border-4 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
        <CardContent className="p-4 text-center">
          <div className="w-12 h-12 mx-auto bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center mb-2">
            <CheckCircle className="w-6 h-6 text-white" />
          </div>
          <h3 className="font-bold text-green-900">App Installed! ✅</h3>
          <p className="text-sm text-green-700">You're using Art Seek as an app!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="border-2 border-blue-300 hover:bg-blue-50 rounded-xl"
        >
          <Download className="w-4 h-4 mr-2" />
          Install App
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md border-4 border-purple-300 bg-gradient-to-br from-purple-50 to-pink-50">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-purple-900">
            <Download className="w-6 h-6" />
            Install Art Seek 🎨
          </DialogTitle>
          <DialogDescription className="text-purple-700">
            Add Art Seek to your home screen for the best experience!
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {isIOS ? (
            <>
              <Card className="border-2 border-blue-300 bg-gradient-to-br from-blue-50 to-cyan-50">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold">
                      1
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-blue-900 mb-1">Open Share Menu</p>
                      <p className="text-sm text-blue-800">
                        Tap the <Share className="w-3 h-3 inline" /> Share button at the bottom of Safari
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold">
                      2
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-blue-900 mb-1">Add to Home Screen</p>
                      <p className="text-sm text-blue-800">
                        Scroll down and select "Add to Home Screen"
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold">
                      3
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-blue-900 mb-1">Confirm Installation</p>
                      <p className="text-sm text-blue-800">
                        Tap "Add" in the top right corner
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="bg-gradient-to-r from-yellow-100 to-orange-100 border-4 border-yellow-300 rounded-2xl p-4">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-yellow-700 mt-0.5 flex-shrink-0" />
                  <div className="text-sm">
                    <p className="text-yellow-900 font-bold mb-1">📱 Safari Required</p>
                    <p className="text-yellow-800">
                      Installation only works in Safari browser. If you're in a different browser, open this page in Safari first.
                    </p>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <Card className="border-2 border-green-300 bg-gradient-to-br from-green-50 to-emerald-50">
              <CardContent className="p-4 text-center">
                <Download className="w-12 h-12 mx-auto text-green-600 mb-3" />
                <p className="text-sm text-green-800 mb-3">
                  Your browser will show an installation prompt. Look for a banner or notification at the bottom of your screen.
                </p>
                <p className="text-xs text-green-700">
                  Tap "Install" or "Add to Home Screen" when prompted.
                </p>
              </CardContent>
            </Card>
          )}

          <div className="bg-gradient-to-r from-purple-100 to-pink-100 border-4 border-purple-300 rounded-2xl p-4">
            <h4 className="font-bold text-purple-900 mb-2">✨ Benefits of Installing:</h4>
            <ul className="text-sm text-purple-800 space-y-1">
              <li>• 📱 Quick access from your home screen</li>
              <li>• 🚀 Faster loading and smoother performance</li>
              <li>• 📴 Works offline after installation</li>
              <li>• 🎨 Full screen app experience</li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
