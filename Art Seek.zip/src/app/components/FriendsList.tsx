import { UserPlus, Users, Star, Trophy, Sparkles, X } from 'lucide-react';
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Avatar, AvatarFallback } from '@/app/components/ui/avatar';
import { Badge } from '@/app/components/ui/badge';
import { ScrollArea } from '@/app/components/ui/scroll-area';
import { InstallInstructions } from '@/app/components/InstallInstructions';
import { toast } from 'sonner';

interface Friend {
  id: string;
  name: string;
  artifactCount: number;
  color: string;
  level: number;
}

const AVATAR_COLORS = [
  'bg-gradient-to-br from-pink-400 to-purple-500',
  'bg-gradient-to-br from-blue-400 to-cyan-500',
  'bg-gradient-to-br from-green-400 to-emerald-500',
  'bg-gradient-to-br from-yellow-400 to-orange-500',
  'bg-gradient-to-br from-red-400 to-pink-500',
  'bg-gradient-to-br from-indigo-400 to-purple-500',
];

export function FriendsList() {
  const [friends, setFriends] = useState<Friend[]>([
    {
      id: '1',
      name: 'Alex',
      artifactCount: 12,
      color: AVATAR_COLORS[0],
      level: 5,
    },
    {
      id: '2',
      name: 'Sam',
      artifactCount: 8,
      color: AVATAR_COLORS[1],
      level: 3,
    },
    {
      id: '3',
      name: 'Jordan',
      artifactCount: 15,
      color: AVATAR_COLORS[2],
      level: 7,
    },
  ]);
  const [newFriendName, setNewFriendName] = useState('');
  const [showAddFriend, setShowAddFriend] = useState(false);

  const handleAddFriend = () => {
    if (newFriendName.trim()) {
      const newFriend: Friend = {
        id: Date.now().toString(),
        name: newFriendName.trim(),
        artifactCount: Math.floor(Math.random() * 10) + 1,
        color: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
        level: Math.floor(Math.random() * 5) + 1,
      };
      setFriends([...friends, newFriend]);
      setNewFriendName('');
      setShowAddFriend(false);
      toast.success('Friend added! 🎉', {
        description: `${newFriend.name} is now in your explorer crew!`,
      });
    }
  };

  const handleRemoveFriend = (id: string) => {
    const friend = friends.find((f) => f.id === id);
    setFriends(friends.filter((f) => f.id !== id));
    toast.info('Friend removed', {
      description: `${friend?.name} has left your explorer crew.`,
    });
  };

  return (
    <div className="p-4 space-y-4">
      {/* Install Card - Show if not installed */}
      {!window.matchMedia('(display-mode: standalone)').matches && 
       !(window.navigator as any).standalone && (
        <Card className="border-4 border-blue-300 bg-gradient-to-br from-blue-50 to-cyan-50 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-full flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-blue-900">Install Art Seek!</h3>
                <p className="text-xs text-blue-700">Add to your home screen</p>
              </div>
            </div>
            <InstallInstructions />
          </CardContent>
        </Card>
      )}

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center">
            <Users className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Explorer Crew</h2>
            <p className="text-sm text-gray-600">{friends.length} friends adventuring!</p>
          </div>
        </div>
        <Button 
          onClick={() => setShowAddFriend(!showAddFriend)}
          className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 gap-2"
        >
          <UserPlus className="w-4 h-4" />
          Add Friend
        </Button>
      </div>

      {showAddFriend && (
        <Card className="border-2 border-purple-200 shadow-lg">
          <CardContent className="p-4">
            <div className="flex gap-2">
              <Input
                placeholder="Enter friend's name..."
                value={newFriendName}
                onChange={(e) => setNewFriendName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newFriendName.trim()) {
                    handleAddFriend();
                  }
                }}
                className="border-2 border-purple-200 focus:border-purple-400"
              />
              <Button 
                onClick={handleAddFriend} 
                disabled={!newFriendName.trim()}
                className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
              >
                Add
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {friends.length === 0 ? (
        <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-dashed border-purple-300">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center mb-4">
              <Users className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No friends yet!</h3>
            <p className="text-gray-600 text-center max-w-xs mb-4">
              Add friends to trade artifacts and explore museums together!
            </p>
          </CardContent>
        </Card>
      ) : (
        <ScrollArea className="h-[500px]">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {friends.map((friend) => (
              <Card 
                key={friend.id} 
                className="border-2 hover:shadow-lg transition-all hover:scale-105 cursor-pointer bg-gradient-to-br from-white to-purple-50"
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Avatar className={`w-14 h-14 ${friend.color} border-2 border-white shadow-md`}>
                      <AvatarFallback className="text-white text-lg font-bold bg-transparent">
                        {friend.name.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold truncate">{friend.name}</h3>
                        <Badge 
                          variant="secondary" 
                          className="bg-gradient-to-r from-yellow-400 to-orange-400 text-white border-0 text-xs"
                        >
                          <Star className="w-3 h-3 mr-1" />
                          Lv {friend.level}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                        <Sparkles className="w-4 h-4 text-purple-500" />
                        <span className="font-semibold text-purple-600">{friend.artifactCount}</span>
                        <span>artifacts found</span>
                      </div>

                      <div className="flex gap-1">
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="flex-1 border-purple-300 hover:bg-purple-100 text-xs"
                        >
                          <Trophy className="w-3 h-3 mr-1" />
                          Trade
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemoveFriend(friend.id);
                          }}
                          className="text-red-500 hover:text-red-600 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}