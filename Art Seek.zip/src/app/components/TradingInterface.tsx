import { useState } from 'react';
import { Users, Send, X, CheckCircle, Gift, Sparkles } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Badge } from '@/app/components/ui/badge';
import { ScrollArea } from '@/app/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/app/components/ui/dialog';
import type { Artifact } from './ArtifactGallery';

interface TradeOffer {
  id: string;
  artifact: Artifact;
  friendName: string;
  status: 'pending' | 'sent';
  date: string;
}

interface TradingInterfaceProps {
  selectedArtifact: Artifact | null;
  onClose: () => void;
  onTrade: (artifactId: string, friendName: string) => void;
}

export function TradingInterface({ selectedArtifact, onClose, onTrade }: TradingInterfaceProps) {
  const [friendName, setFriendName] = useState('');
  const [tradeOffers, setTradeOffers] = useState<TradeOffer[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSendTrade = () => {
    if (selectedArtifact && friendName.trim()) {
      const offer: TradeOffer = {
        id: Date.now().toString(),
        artifact: selectedArtifact,
        friendName: friendName.trim(),
        status: 'sent',
        date: new Date().toISOString(),
      };
      setTradeOffers([offer, ...tradeOffers]);
      onTrade(selectedArtifact.id, friendName.trim());
      setShowSuccess(true);
      setFriendName('');
      
      setTimeout(() => {
        setShowSuccess(false);
        onClose();
      }, 2000);
    }
  };

  return (
    <Dialog open={!!selectedArtifact} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl border-4 border-purple-300 bg-gradient-to-br from-purple-50 to-pink-50">
        <DialogHeader>
          <DialogTitle className="text-2xl text-purple-900 flex items-center gap-2">
            <Gift className="w-6 h-6 text-pink-500" />
            Share with Friends! 🎁
          </DialogTitle>
          <DialogDescription className="text-purple-700">
            Send this amazing artifact to your explorer crew!
          </DialogDescription>
        </DialogHeader>

        {showSuccess ? (
          <div className="flex flex-col items-center justify-center py-12">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center mb-4 shadow-lg animate-bounce">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            <h3 className="text-2xl mb-2 font-bold text-purple-900">Trade Sent! 🎉</h3>
            <p className="text-gray-600">Your friend will love this artifact!</p>
          </div>
        ) : (
          selectedArtifact && (
            <div className="space-y-6">
              <Card className="border-4 border-purple-200 bg-gradient-to-br from-white to-purple-50">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <img
                      src={selectedArtifact.image}
                      alt={selectedArtifact.name}
                      className="w-24 h-24 object-cover rounded-xl border-4 border-white shadow-lg"
                    />
                    <div className="flex-1">
                      <h4 className="font-bold mb-1 text-purple-900">✨ {selectedArtifact.name}</h4>
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {selectedArtifact.description || 'No description'}
                      </p>
                      <Badge className="mt-2 text-xs bg-gradient-to-r from-yellow-400 to-orange-500 border-0">
                        📅 {new Date(selectedArtifact.dateScanned).toLocaleDateString()}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-2">
                <Label htmlFor="friend" className="text-purple-900 font-semibold">👥 Friend's Name</Label>
                <div className="flex gap-2">
                  <Input
                    id="friend"
                    placeholder="Enter friend's name..."
                    value={friendName}
                    onChange={(e) => setFriendName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && friendName.trim()) {
                        handleSendTrade();
                      }
                    }}
                    className="border-2 border-purple-300 focus:border-purple-500 rounded-xl"
                  />
                  <Button 
                    onClick={handleSendTrade} 
                    disabled={!friendName.trim()}
                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 rounded-xl"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Send
                  </Button>
                </div>
              </div>

              <div className="bg-gradient-to-r from-blue-100 to-purple-100 border-4 border-blue-200 rounded-2xl p-4">
                <div className="flex items-start gap-3">
                  <Sparkles className="w-6 h-6 text-purple-600 mt-0.5 flex-shrink-0" />
                  <div className="text-sm">
                    <p className="text-purple-900 font-bold mb-1">🎮 Pro Tip!</p>
                    <p className="text-purple-800">
                      Trade artifacts with your explorer crew to complete your collection faster and unlock special rewards!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )
        )}
      </DialogContent>
    </Dialog>
  );
}

export function TradeHistory() {
  // Mock trade history for demonstration
  const mockTrades: TradeOffer[] = [
    {
      id: '1',
      artifact: {
        id: 'mock1',
        image: 'https://images.unsplash.com/photo-1567696911980-2eed69a46042?w=400',
        name: 'Mock Ancient Sculpture',
        description: 'Example artifact from previous trade',
        dateScanned: new Date(Date.now() - 86400000 * 7).toISOString(),
      },
      friendName: 'Alex',
      status: 'sent',
      date: new Date(Date.now() - 86400000 * 2).toISOString(),
    },
  ];

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
          <Gift className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-purple-900">Trade History 🎁</h2>
          <p className="text-sm text-gray-600">Your artifact exchanges</p>
        </div>
      </div>
      
      {mockTrades.length === 0 ? (
        <Card className="border-4 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center mb-4">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-bold text-lg mb-2 text-purple-900">No Trades Yet! 🎮</h3>
            <p className="text-gray-600 text-center max-w-xs">
              Start sharing artifacts with your explorer crew to begin your trading journey!
            </p>
          </CardContent>
        </Card>
      ) : (
        <ScrollArea className="h-[500px]">
          <div className="space-y-3">
            {mockTrades.map((trade) => (
              <Card key={trade.id} className="border-4 border-purple-200 hover:shadow-lg transition-all bg-gradient-to-br from-white to-purple-50">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <img
                      src={trade.artifact.image}
                      alt={trade.artifact.name}
                      className="w-20 h-20 object-cover rounded-xl border-4 border-white shadow-md"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-1">
                        <h4 className="font-bold text-purple-900">✨ {trade.artifact.name}</h4>
                        <Badge className={trade.status === 'sent' ? 'bg-gradient-to-r from-green-400 to-emerald-500 border-0' : 'bg-gray-400 border-0'}>
                          {trade.status === 'sent' ? '✅ Sent' : trade.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">
                        🎁 Shared with <span className="font-bold text-purple-700">{trade.friendName}</span>
                      </p>
                      <p className="text-xs text-gray-500">
                        📅 {new Date(trade.date).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}