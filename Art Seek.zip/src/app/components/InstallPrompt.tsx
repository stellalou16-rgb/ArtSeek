import { useState, useEffect } from 'react';
import { Download, X, Share } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Card, CardContent } from '@/app/components/ui/card';

export function InstallPrompt() {
  const [showPrompt, setShowPrompt] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if it's iOS
    const ios = /iPad|iPhone|iPod/.test(navigator.userAgent);
    setIsIOS(ios);

    // Check if app is already installed (standalone mode)
    const standalone = window.matchMedia('(display-mode: standalone)').matches ||
                      (window.navigator as any).standalone ||
                      document.referrer.includes('android-app://');
    setIsStandalone(standalone);

    // Check if user has dismissed the prompt before
    const dismissed = localStorage.getItem('installPromptDismissed');
    
    if (!standalone && !dismissed) {
      // For Android/Chrome - listen for beforeinstallprompt event
      const handler = (e: any) => {
        e.preventDefault();
        setDeferredPrompt(e);
        setShowPrompt(true);
      };
      
      window.addEventListener('beforeinstallprompt', handler);

      // For iOS - show manual instructions after a delay
      if (ios) {
        setTimeout(() => {
          setShowPrompt(true);
        }, 3000);
      }

      return () => {
        window.removeEventListener('beforeinstallprompt', handler);
      };
    }
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      // Android/Chrome installation
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
      setShowPrompt(false);
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem('installPromptDismissed', 'true');
  };

  // Don't show if already installed or dismissed
  if (!showPrompt || isStandalone) {
    return null;
  }

  return (
    <div className="fixed bottom-20 left-0 right-0 z-50 px-4 animate-in slide-in-from-bottom-5">
      <Card className="max-w-md mx-auto border-4 border-purple-300 bg-gradient-to-br from-purple-50 to-pink-50 shadow-2xl">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg rotate-12">
              <Download className="w-6 h-6 text-white -rotate-12" />
            </div>
            
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-purple-900 mb-1">Install Art Seek! 🎨</h3>
              
              {isIOS ? (
                <div className="text-sm text-gray-700 space-y-2">
                  <p>Add to your home screen for the best experience!</p>
                  <ol className="space-y-1 text-xs">
                    <li className="flex items-center gap-2">
                      <span className="font-bold text-blue-600">1.</span>
                      <span>Tap the <Share className="w-3 h-3 inline" /> Share button below</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="font-bold text-blue-600">2.</span>
                      <span>Scroll and tap "Add to Home Screen"</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="font-bold text-blue-600">3.</span>
                      <span>Tap "Add" in the top right</span>
                    </li>
                  </ol>
                </div>
              ) : (
                <p className="text-sm text-gray-700 mb-3">
                  Install the app for quick access and offline use!
                </p>
              )}

              <div className="flex gap-2 mt-3">
                {!isIOS && deferredPrompt && (
                  <Button 
                    onClick={handleInstallClick}
                    size="sm"
                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 rounded-xl"
                  >
                    Install Now
                  </Button>
                )}
                <Button 
                  onClick={handleDismiss}
                  size="sm"
                  variant="ghost"
                  className="text-gray-600"
                >
                  <X className="w-4 h-4 mr-1" />
                  Not Now
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
