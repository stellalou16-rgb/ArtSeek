# 📱 Art Seek - Install as an App on iPhone

Art Seek is now a Progressive Web App (PWA) that can be installed on your iPhone and used like a native app!

## ✨ What You Get

- **📲 Home Screen Icon**: Beautiful app icon on your iPhone home screen
- **🚀 Full Screen Mode**: Runs without browser UI, just like a native app
- **📴 Works Offline**: Use the app even without internet connection
- **⚡ Faster Performance**: Optimized loading and caching
- **🎨 Native Feel**: Smooth animations and transitions
- **📍 Camera & GPS**: Full access to device features

## 📲 Installation Steps for iPhone

### ✅ Requirements
- **iPhone** with iOS 12.2 or later (works on ALL iPhones from iPhone 5S and newer)
- **Safari browser** (must use Safari - Chrome/Firefox won't work for installation)
- Internet connection for initial setup

### 📱 Step-by-Step Guide

#### 1. **Open in Safari**
   - Make sure you're using **Safari** (the blue compass icon)
   - Navigate to your Art Seek web app URL
   - If you're in another browser, copy the URL and paste it in Safari

#### 2. **Tap the Share Button**
   - Look at the **bottom of your screen** (or top on iPad)
   - Tap the **Share** button (square icon with an arrow pointing up)
   
#### 3. **Find "Add to Home Screen"**
   - Scroll down in the share menu
   - Tap **"Add to Home Screen"** 
   - You may need to scroll down a bit to find it

#### 4. **Customize & Add**
   - You'll see the app icon and name preview
   - You can edit the name if you want (default: "Art Seek")
   - Tap **"Add"** in the top right corner

#### 5. **Done! 🎉**
   - Look for the Art Seek icon on your home screen
   - Tap it to launch the app
   - It opens full screen like any native app!

## 🎯 First Time Setup

After installation:

1. **Allow Camera Access**: Tap "Allow" when prompted to scan artifacts
2. **Enable Location**: Tap "Allow" to automatically tag museum locations
3. **Start Exploring**: Begin collecting artifacts and leveling up!

## 📱 Compatible Devices

**All Modern iPhones:**
- iPhone 15 Pro Max, 15 Pro, 15 Plus, 15
- iPhone 14 Pro Max, 14 Pro, 14 Plus, 14
- iPhone 13 Pro Max, 13 Pro, 13 Mini, 13
- iPhone 12 Pro Max, 12 Pro, 12 Mini, 12
- iPhone 11 Pro Max, 11 Pro, 11
- iPhone XS Max, XS, XR, X
- iPhone 8 Plus, 8, 7 Plus, 7
- iPhone SE (1st, 2nd, and 3rd generation)
- iPhone 6S Plus, 6S

**iPads:**
- All iPad Pro models
- iPad Air (3rd gen and later)
- iPad (5th gen and later)
- iPad Mini (4th gen and later)

**iOS Versions:**
- iOS 17, 16, 15, 14, 13, 12.2+

## 💡 Pro Tips

### Permissions
- **Camera**: Required for scanning artifacts in museums
- **Location**: Optional but recommended for GPS tagging
- **Storage**: Your collection saves automatically on your device

### Best Practices
- **Good Lighting**: Take photos in well-lit areas for best results
- **WiFi for Initial Load**: First install works better on WiFi
- **Update iOS**: For best experience, keep iOS updated
- **Storage**: App uses minimal storage, photos are compressed

### Troubleshooting

**Can't Find "Add to Home Screen"?**
- Make sure you're in Safari (not Chrome/Firefox)
- Try updating to the latest iOS version
- Check if you've scrolled down in the Share menu

**App Won't Open Camera?**
- Go to Settings → Safari → Camera → Allow
- Or Settings → Art Seek → Camera → Allow

**App Looks Wrong?**
- Close and reopen the app
- Make sure you have good internet connection
- Try uninstalling and reinstalling

## 🌐 Sharing with Friends

Want your friends to join?

1. **Share the Link**: Send them your Art Seek URL
2. **They Install**: They follow the same steps above
3. **Add Each Other**: Use the "Friends" tab to connect
4. **Start Trading**: Begin exchanging artifacts!

## 📊 Features After Installation

✅ **Camera Scanning**: Capture museum artifacts with your camera  
✅ **Gallery Management**: View and organize your collection  
✅ **Museum Tracking**: See which museums you've visited  
✅ **Friend System**: Add friends and trade artifacts  
✅ **Level Progression**: Earn XP and level up as you collect  
✅ **GPS Tagging**: Auto-tag locations of discoveries  
✅ **Offline Access**: Browse your collection anytime  

## 🔐 Privacy & Security

- All data is stored **locally on your device**
- No server uploads of your photos
- Camera access only when you tap the scan button
- Location tracking only when scanning artifacts
- You control all your data

## 🆘 Need Help?

**Installation Issues:**
- Ensure you're using Safari browser
- Update to latest iOS version (Settings → General → Software Update)
- Free up device storage if needed
- Try in Private/Incognito mode if problems persist

**App Issues:**
- Close and reopen the app
- Clear Safari cache (Settings → Safari → Clear History)
- Reinstall the app by deleting from home screen and adding again

---

**Ready to explore? Install Art Seek now and start your museum adventure! 🎨✨🏛️**